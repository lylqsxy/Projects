﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cobra.Models
{
    public class Coordinate
    {
        public float Lat { get; set; }
        public float Lng { get; set; }
    }
}