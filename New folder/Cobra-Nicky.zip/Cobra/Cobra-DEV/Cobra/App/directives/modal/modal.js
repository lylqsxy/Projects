﻿angular.module('cobraModal', ['xeditable']);

