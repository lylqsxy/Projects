﻿using Microsoft.AspNet.Identity;

namespace Cobra.App.Infrastructure.Contracts
{
    public interface ISmsSendingService : IIdentityMessageService
    {
    }
}