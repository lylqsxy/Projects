Use Cobra
go
insert into AddressType (Name) values('Work')
insert into AddressType (Name) values('Home')
insert into EmailType (Name) values('Home')
insert into EmailType (Name) values('Work')
insert into Country (Name,CountryCode,PhoneCode) values('New Zealand','NZ',064)
insert into PhoneType (Name) values('Work')
insert into PhoneType (Name) values('Home')
insert into Relationship (RelationshipToYou) values('Father')
insert into Relationship (RelationshipToYou) values('Mother')
insert into Organisation (OrgName,WebsiteUrl,CreatedOn,
CreatedBy,UpdatedBy,UpdatedOn,IsActive) values('MVPStudio','www.mvpstudio','2016-08-01 11:00:00',
0,0,'2016-09-15 14:47:00',1)

